# Team-California:-> The user will be presented with the option of logging in using an existing InCollege account or creating a
new InCollege account. In this epic, support for up to 5 unique student accounts (unique user name and
secure password: minimum of 8 characters, maximum of 12 characters, at least one capital letter, one
digit, one special character) will be provided. Any student accounts that are created will be saved and
will be read back into the system the next time the application is started up. The 6th attempt to create a
student account will result in the message "All permitted accounts have been created, please come back
later" to be displayed to the user. If the student successfully logs in by entering a recognized username /
password, the system will tell them "You have successfully logged in". If they enter an incorrect
username / password, the system will tell them "Incorrect username / password, please try again" and
will allow the student to attempt to log in again. An unlimited number of log in attempts will be
permitted.
Once logged in, additional options will be provided that will allow the user to search for a job, find
someone that they know, or learn a new skill. The job search/internship option will result in an "under
construction" message. "Find someone you know" will result in an "under construction" message.
"Learn a new skill" will present the student with a list of skills that they can learn – you make up this list
of 5 skills. Selecting any of these skills will result in an "under construction" message. The user will be
also presented with an option to not select a skill and to return to the previous level (top level). 
